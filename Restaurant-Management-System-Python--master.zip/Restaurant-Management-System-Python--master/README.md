# Restaurant-Management-System-Python-
Restaurant-Management-System in python(tkinter) , GUI based project for college students in python using module tkinter, Based on new boston tutorials with some added tabs and functions.
