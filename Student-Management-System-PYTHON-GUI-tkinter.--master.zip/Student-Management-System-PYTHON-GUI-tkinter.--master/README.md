# Student-Management-System-PYTHON-GUI-tkinter.-
This repository contains Student Management System.
1. It is made in PYTHON Language.
2. This program imports tkinter and sqlite3.
3. It asks user to enter Name, College, Phone number & address.
4. When user click on Display result a new window opens and shows all the entries.  
5. Screenshot of the output window is attached as PNG file.
