a = input('Enter')
print(type(a))