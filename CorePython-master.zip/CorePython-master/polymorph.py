# add = lambda x, y: x + y
#
# print(add(2, 3))


def swap(a,b):
    a,b = b,a
    print(a,b)

def multi(c,d):
    e = c*d
    print(e)
