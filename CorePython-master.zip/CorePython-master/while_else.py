a = 10
while a>20:
    print(a)

print(a+3)