# a=[1,2,3]
# b=[4,5,6]
#
# c=a[0]+b[0],a[1]+b[1],a[2]+b[2]
# print(c)
#
#
# a=20
# b=2
#
#
# for i in range(9):
#     if a-b==0 or()