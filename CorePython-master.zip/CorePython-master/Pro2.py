class student:
    sem="vii"

s=student()

s.name="Ashini"
s.surname="Rami"
s.enroll=21
s.course="Biomedical"
s.address="Surat"
s.sem = 'gg'

print(s.name)
print(s.surname)

s1=student()


s1.name="Kushal"
s1.surname="Bhavsar"
s1.enroll=18
s1.course="Diploma"
s1.address="A'bad"

print(s1.name)
print(s1.surname)
print(student.sem)