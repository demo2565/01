# from gtts import gTTS
#
# mytext = 'Hello I am kushal Bhavsar  I am a python Developer'
# myobj = gTTS(text=mytext,lang='hin')
# myobj.save("welcome1.mp3")

import pyqrcode
k = pyqrcode.create('kushal')
k.png('k.png')

