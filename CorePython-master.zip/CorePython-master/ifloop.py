##LOOP
##For loop
# for i in range(10):
#     for j in range(i):
#         print('*',end = ' ')
#     print()
/
for i in range(10):
    for j in range(i):
        print("$",end='ku')
    print()




# maths = int(input('Enter your Maths marks'))
# sci = int(input('Enter your Science marks'))
# SS = int(input('Enter your SS marks'))
# comp = int(input('Enter your Computer marks'))
# Hin = int(input('Enter your Hindi marks'))
#
# total = maths+sci+SS+comp+Hin
# perc = total/500*100
#
# print('Your Total marks is:',total)
# print('Your percentage is :',perc)
# top=80
# med=60
# low=50
# if perc>top:
#     print('your performance is good')
#
# top = 80
# med = 60
# low = 40
#
# if perc > top:
#     print('Your perfomance in outstanding ,Keep it up')
# if perc<top:
#     print('you are failed')
# if med<perc<top:
#     print('your performance is very good,but do better')
# if low<perc<med:
#     print('you need an improvement')
#
# if med<perc<top:
#     print('You perfomance is very good,but you can do better')
#
# if low<perc<med:
#     print('You needs an Improvement')
#
# if perc<low:
#     print('You failed')