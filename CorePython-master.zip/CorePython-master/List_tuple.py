##Tuple

b = (7,8,9,10)
print(b.index(7))
# ###without List comprehension
# k  = []
# for i in 'Kushal Bhavsar':
#     k.append(i)
# print(k)
#
# ##With list comprehension
#
# p = [h for h in 'Kushal Bhavsar']
# print(p)