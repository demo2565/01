class student:
    pass

s = student()
s.surname="Rami"
s.enroll=21
s.course="Biomedical"

s1 = student()
s1.surname = 'BHavsar'
s1.enrollment = '007'
s1.course = "IT"

print(s1)