for i in range(0,10):
    for j in range(0,i):
        print('*',end = '_')
    print()