a = input('Enter you name: ')
b = input('Enter you surname: ')

if a == 'Kushal':
    if b == 'Bhavsar':
        print('Hello' +' '+ a +' '+ b)
    else:
        print('your surname is incorrect')