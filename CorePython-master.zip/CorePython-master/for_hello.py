usd = int(input('Enter the  USD$: '))

inr = usd*70
print('Your INR value is:', inr)