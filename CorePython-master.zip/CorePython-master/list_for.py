for i in range(15):
    for j in range(i):
        print('*',end = 'k')
    print()