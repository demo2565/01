def print_me():
    print("kushal")
print_me()
print_me()
print_me()



#######Function
def add(a,b):
    c=a+b
    return c


def div(x, d):
    p = x/2
    return p

def mul(p,e):
    q=p*e
    return q


x=add(2,2)
p=div(x,2)
z=mul(p,64)
print(z)


