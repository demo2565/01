print("Mathematical operation programs")
a=int(input("enter the value of a:"))
b=int(input("enter the value of b:"))

c=a+b
print(c)

c=a-b
print(c)

c=a*b
print(c)

c=a/b
print(c)

c=a%b
print(c)