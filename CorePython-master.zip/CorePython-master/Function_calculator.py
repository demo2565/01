
from  function_operation import addition,multi
x = 10
y = 20
addition(x,y)
multi(x,y)
# a=int(input("enter the value of a:"))
# b=int(input("enter the value of b:"))
#
# print("Choose the operation")
# print("+")
# print("-")
# print("*")
# print("/")
#
# choice=(input("enter choice :"))
#
# def add(a,b):
#     c=a+b
#     if choice == '+':
#         print(c)
#         print("sum of a and b is %d" %c)
# add=add(a,b)
#
# def sub(a,b):
#     d=a-b
#     if choice=='-':
#         print(d)
#         print("Substraction of a and b is %d" %d)
# Sub=sub(a,b)
#
# def Mult(a,b):
#     e=a*b
#     if choice=='*':
#         print(e)
#         print("Multification of a and b is %d" %e)
# mult=Mult(a,b)
#
# def division(a,b):
#     f=a/b
#     if choice=='/':
#         print(f)
#         print("division of a and b is %d" %f)
# div=division(a,b)