sa = [0,1,2,3,4,5,'kushal']
# print(sa[5])


###Slicing
# print(sa[2:4])

##Iteration of List
for i in sa[6]:
    print(i)


#
# ##membership (IN, NOT IN)
# a=[4,5,6]
# b=[1,2,3]
# if (5 in a):
#     print("5 in b list")
# else:
#     print("not found")
#
# ###concate
# c=a+b
# print("new list  c",c)
#
# # ###Itration
# # for k in c:
# #     print(k)
# #
# ###Update list
# d=[1,2,3,4,5]
# d[2]=6
# print("list d\n",d)
#
# #
# # ####Delete List
#
# del d
# print(d)
