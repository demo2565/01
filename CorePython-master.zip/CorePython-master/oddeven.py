# a=int(input("enter the value of a:"))
#
# if(a%2)==0:
#     print("Given number is even")
# else:
#      print("given number is odd")