from tkinter import Tk
from pdfviewer import PDFViewer


def main():
    root = Tk()
    PDFViewer()
    root.mainloop()


if __name__ == '__main__':
    main()
