from pdfviewer.config import *
from pdfviewer.display_canvas import DisplayCanvas
from pdfviewer.helpbox import HelpBox
from pdfviewer.hoverbutton import HoverButton
from pdfviewer.menubox import MenuBox
from pdfviewer.tooltip import ToolTip
from pdfviewer.pdfviewer import PDFViewer


name = 'pdfviewer'
