import os


ROOT_PATH = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
BACKGROUND_COLOR = '#303030'
HIGHLIGHT_COLOR = '#558de8'
